using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Linq;
using System.Collections.Generic;
using System.Net.Http;

namespace ReadExcel
{
    public static class RowColumnCount
    {
        [FunctionName("RowColumnCount")]
        public static string Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {

            {


                var file = req.Form.Files["file"];
                var count = req.Query["count"];
      


                {
                    try
                    {
                        DataTable dtTable = new DataTable();
                        var filestream = file.OpenReadStream();

                        using (SpreadsheetDocument doc = SpreadsheetDocument.Open(filestream, false))
                        {

                            WorkbookPart workbookPart = doc.WorkbookPart;
                            Sheets thesheetcollection = workbookPart.Workbook.GetFirstChild<Sheets>();


                            foreach (Sheet thesheet in thesheetcollection.OfType<Sheet>())
                            {

                                Worksheet theWorksheet = ((WorksheetPart)workbookPart.GetPartById(thesheet.Id)).Worksheet;

                                SheetData thesheetdata = theWorksheet.GetFirstChild<SheetData>();



                                for (int rCnt = 0; rCnt < thesheetdata.ChildElements.Count(); rCnt++)
                                {
                                    List<string> rowList = new List<string>();
                                    for (int rCnt1 = 0; rCnt1
                                        < thesheetdata.ElementAt(rCnt).ChildElements.Count(); rCnt1++)
                                    {



                                        Cell thecurrentcell = (Cell)thesheetdata.ElementAt(rCnt).ChildElements.ElementAt(rCnt1);

                                        string currentcellvalue = string.Empty;
                                        if (thecurrentcell.DataType != null)
                                        {
                                            if (thecurrentcell.DataType == CellValues.SharedString)
                                            {
                                                int id;
                                                if (Int32.TryParse(thecurrentcell.InnerText, out id))
                                                {
                                                    SharedStringItem item = workbookPart.SharedStringTablePart.SharedStringTable.Elements<SharedStringItem>().ElementAt(id);
                                                    if (item.Text != null)
                                                    {

                                                        if (rCnt == 0)
                                                        {
                                                            dtTable.Columns.Add(item.Text.Text);
                                                        }
                                                        else
                                                        {
                                                            rowList.Add(item.Text.Text);
                                                        }
                                                    }
                                                    else if (item.InnerText != null)
                                                    {
                                                        currentcellvalue = item.InnerText;
                                                    }
                                                    else if (item.InnerXml != null)
                                                    {
                                                        currentcellvalue = item.InnerXml;
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (rCnt != 0)
                                            {
                                                rowList.Add(thecurrentcell.InnerText);
                                            }
                                        }
                                    }
                                    if (rCnt != 0)
                                        dtTable.Rows.Add(rowList.ToArray());

                                }

                            }

                            string names = JsonConvert.SerializeObject(dtTable);

                            List<string> result = names.Split(',').ToList();





                            //     return JsonConvert.SerializeObject(dtTable);

                            log.LogInformation(dtTable.Rows.ToString());
                            //       return dtTable;
                            string returnmessage = dtTable.Rows.Count.ToString();
                            //   return dbTable.Rows.ToString();

                            if (count == "rows" || count == "row")
                            {
                                return dtTable.Rows.Count.ToString();
                            }

                            if (count == "columns" || count == "column")
                            {
                                return dtTable.Columns.Count.ToString();
                            }
                            else
                            {
                                return "Use Rows or Columns for Count input";
                            }


                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        throw;
                    }
                }
            }




        }
    }
}

