﻿using System;
namespace Andys.Function
{
    public class s3mod
    {
        public string name { get; set; }
        public string value { get; set; }
    }
}
