XE.com Nintex Workflow Cloud - Xtension

Description
-----------
XE.com is one of the leaders in online currency conversion technology.  This Nintex Workflow Cloud Xtension, allows you to add 8 actions to your Nintex Workflow Cloud designer.  You'll then be able to convert currencies and get historical data, all from your workflow design.

Installing the Xtension
-----------------------
Navigate to your Nintex Workflow Cloud tenant, on the left menu, click on XTensions.
Click on the plus button and upload the xe_com_xtension.json file. 
You will be presented with the option to add an image.  Upload the XE.com.png file.

Getting an XE.com API Key
-------------------------
Make sure you create an account on XE.com (trial will work for 7 days).
Then go to - https://xecd.xe.com/

Once you verify your account, you'll be presented with an Account ID and Account API Key.  These will be your username/password combination for the basic authentication that the XE.com api supports.

Using the XTension
------------------
In Nintex Workflow Cloud, create a Connection, using the above Account ID and Account API Key as the username/password combination.

The click on Workflows and "import", and import the below workflow:
Example NWC Workflow - m8hFVq6S1isvhRJWSdmwHphsRurYmnvh6X9NUykjH23Z3XzCa

This will show you how to use the 8 actions that are available with this NWC Xtension.