Countries Nintex Workflow Cloud - Xtensions

Description
-----------
Rest Countries is a service that is now owned and maintained by APILayer.  This is a free rest service at this stage.  It allows you to retrieve data about countries.  Examples include, full names, domain names, calling codes, population, coordinates, timezones, currencies, bordering countries, numeric code, languages, and capital cities (among others).

This Nintex Workflow Cloud Xtension, will give you the ability to communicate with this service, to extract the data you need, so that you can make your workflow processes, even better.

eg. you're creating a workflow that uses Document Generation, to create documents on the fly.  You work at a multi-national company, or have international clients, to which those documents will be going.  You are looking at putting currency values into those documents, but you want the currency symbol, to be appropriate for the destination country.  This will allow you to do this.

Installing the Xtension
-----------------------
Navigate to your Nintex Workflow Cloud tenant, on the left menu, click on XTensions.
You will need to do the following steps, for each JSON file.
Click on the plus button and upload the json file. 
You will be presented with the option to add an image.  Upload the Countries.png file.

Authentication
-------------------------
There is not auth needed for this service, as of 25th January, 2020.

More information about this service can be found here: https://restcountries.eu/

Using the XTension
------------------
All the actions in this Xtensions, return a collection of data.  So store the result in a Collection variable.  That variable will contain 1 to many text values (all in JSON format).  You will need the Query JSON action to parse that data.

Examples of extracting the data from the JSON.
Capital - $.capital
Numeric Code - $.numericCode
First Currency Symbol - $.currencies.[0].symbol