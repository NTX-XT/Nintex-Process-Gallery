OpenWeather Nintex Workflow Cloud - Xtensions

Description
-----------
More information about the OpenWeather api can be found here : https://openweathermap.org/api

Installing the Xtension
-----------------------
Navigate to your Nintex Workflow Cloud tenant, on the left menu, click on XTensions.
You will need to do the following steps, for each JSON file.
Click on the plus button and upload the json file. 
You will be presented with the option to add an image.  Upload the openweather.png file.

Getting an OpenWeather API Key
-------------------------
Make sure you sign up for an account on https://openweathermap.org/api.
You'll then get an email with you API key.  If you don't, go to your profile and you'll find your api key there.

Using the XTension
------------------
In Nintex Workflow Cloud, create a Connection, using the API Key.

All the actions in these Xtensions, return text.  It'll be in JSON format, and you will need the Query JSON action, to parse that data.

Workflow Export Key : P7nohzCLteoiVQJYvAvDKGCU9HMTnn2h2Jj2EV31HzcQ2XSM8