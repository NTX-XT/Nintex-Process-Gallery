AccuWeather Nintex Workflow Cloud - Xtensions

Description
-----------
AccuWeather is one of the online leaders in weather and forecasting data.

Installing the Xtension
-----------------------
Navigate to your Nintex Workflow Cloud tenant, on the left menu, click on XTensions.
You will need to do the following steps, for each JSON file.
Click on the plus button and upload the json file. 
You will be presented with the option to add an image.  Upload the AccuWeather.com.png file.

Getting an AccuWeather API Key
-------------------------
Make sure you register for an account on https://developer.accuweather.com/.
Then go to : https://developer.accuweather.com/user/me/apps

Generate a new app.  You will get an api key.  You'll need to use this in NWC.

Using the XTension
------------------
In Nintex Workflow Cloud, create a Connection, using the API Key.

All the actions in these Xtensions, return text.  It'll be in JSON format, and you will need the Query JSON action, to parse that data.