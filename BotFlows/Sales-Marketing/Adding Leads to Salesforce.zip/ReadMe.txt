Before running this botflow, the Credential item "Salesforce" needs to be updated to reflect usable credentials in your Salesforce org.

Additionally, before running this botflow the data must be loaded. In the Menu Bar (top), click the 'Data' menu and choose 'Open Data' (alternatively, press Ctrl+D). From there, navigate to where the file "Leads to Add Data.accdb" is saved and choose this file to open.

NOTE: The Salesforce org this botflow was created in my be different than the Salesforce org you are using. There may be some adjustments needed in the botflow to account for these differences.