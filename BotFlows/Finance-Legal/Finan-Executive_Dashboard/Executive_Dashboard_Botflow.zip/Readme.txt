Extract the contents of the zip into a folder on your desktop and run the botflow. 

NOTE: All of the files must be located in a folder named "RPA_Demo" on your desktop for the botflow to successfully run. (This can be changed within the botflow.)