After unzipping everything, the folder "Word Find and Replace" must be placed on your Desktop. The document "Barcode Sample.docx" must be in this folder.

NOTE: This botflow was created in Word for Office 365. There may be some adjustments needed in the botflow to account for any differences in another version of Microsoft Office.