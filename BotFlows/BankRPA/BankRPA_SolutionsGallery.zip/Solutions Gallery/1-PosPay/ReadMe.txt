Place PosPay folder on C: \

www.bankrpa.com