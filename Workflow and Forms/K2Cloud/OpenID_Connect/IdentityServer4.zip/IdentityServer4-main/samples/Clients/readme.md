The client samples are designed to be used with the host in this repo:

https://github.com/IdentityServer/IdentityServer4/tree/main/src/IdentityServer4
