.\clean.ps1
.\build.ps1 quick