git clean -xdf -e samples -e src/IdentityServer4/.vs

./clean_cache.ps1