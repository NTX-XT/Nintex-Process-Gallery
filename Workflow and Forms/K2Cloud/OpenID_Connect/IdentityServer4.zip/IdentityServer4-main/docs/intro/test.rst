Demo Server
===========

You can try IdentityServer4 with your favourite client library. We have a test instance at `demo.identityserver.io <https://demo.identityserver.io>`_. 
On the main page you can find instructions on how to configure your client and how to call an API.
