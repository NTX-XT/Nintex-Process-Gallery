---
name: Question
about: Ask a simple question.
labels: question
---

<!--
  ⚠️ ⚠️ ⚠️ ⚠️ ⚠️ ⚠️
Questions are community supported only and the authors/maintainers may or may not have time to reply. If you or your company would like commercial support, please see [here](https://identityserver4.readthedocs.io/en/latest/intro/support.html#commercial-support) for more information.
  ⚠️ ⚠️ ⚠️ ⚠️ ⚠️ ⚠️
-->


### Question


### Minimal working example

```csharp
   // <code goes here>
```

### Relevant parts of the log file

```
   <log goes here>
```
