﻿# K2 TypeScript Broker Generator
This is a CLI which can be used to generate a K2 Broker by providing a Swagger v2.0 or OpenAPI v3.0 definition as input.

This project is located on NPM at [JSSPBuilder](https://www.npmjs.com/package/jsspbuilder)

# Features
  
- Generates a TypeScript code file (index.ts) from a Swagger v2.0 or OpenAPI v3.0 definition file (json format)

- Dynamic flattening of complex objects up to user defined level in describe schema

- Dynamic flattening of returned data for complex objects

## Getting Started

This CLI requires [Node.js](https://nodejs.org/) v12.14.1+ to run.

## Usage

1. Clone the K2 JavaScript broker template into a new directory:
```sh
git clone https://github.com/K2Documentation/K2Documentation.Samples.JavascriptBroker.Template.git mynewbroker

cd mynewbroker
```

2. Install K2 Broker dependencies:
```sh
npm install
```


3. Install the JSSPBuilder CLI globally:
```bash
npm install jsspbuilder -g
```

4. Copy/Save you swagger/openAPI definition file to the project folder
```bash
copy [your_definition_file] swagger.json
```

>**Note**: If you want to integrate with an OData v4.0 service, you can make use of our OData v4.0 to >OpenAPI v3.0 conversion service.
>The service is at https://odata4edmtoopenapi3converter.azurewebsites.net/swagger/index.html

5. Run the JSSPBuilder CLI:

Interactive...
```bash
jsspbuilder
```

or with parameters
```bash
jsspbuilder --filename=swagger.json --flatten=2 --outputdir=src
```

>**Note**: If an index.ts file existed before running jsspbuilder, it will be renamed index.ts_bak1


6. Follow the instructions to build and publish your broker to a K2 Cloud instance :   
[@k2oss/k2-broker-core](https://www.npmjs.com/package/@k2oss/k2-broker-core)