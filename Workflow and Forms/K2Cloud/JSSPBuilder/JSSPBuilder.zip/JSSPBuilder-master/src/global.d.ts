
interface SwaggerDefinition {
    swagger: string;
    info: {
      title: string;
      version: string;
      description?: string;
    };
    host: string;
    schemes: string[];
    paths: {
      [name: string]: {
        [name: string]: SwaggerMethod;
      };
    };
    definitions: {
      [name: string]: {
        type?: string;
        description?: string;
        required?: any[];
        properties: {
          [name: string]: any;
        };
      };
    };
    securityDefinitions: any;
    security?: any[];
    parameters?: any;
    tags?: Array<{ name: string; description: string }>;
  }
  
  interface SwaggerMethod {
    tags?: string[];
    description?: string;
    operationId: string;
    produces: string[];
    parameters?: SwaggerParameter[];
    consumes?: string[];
    responses: SwaggerMethodResponse;
    security?: any[];
  }
  
  interface SwaggerMethodResponse {
    [name: string]: {
      description?: string;
      schema: any;
      examples?: any;
    };
  }
  
  interface SwaggerParameter {
    $ref?: string;
    name: string;
    description?: string;
    in: string;
    required: boolean;
    type?: string;
    format?: string;
    schema?: {
      $ref: string;
    };
    enum?: string[];
    "x-example"?: string;
  }

  interface OpenAPIDefinition {
    openapi: string;
    info: {
      title: string;
      version: string;
      description?: string;
    };
    servers: [ { url:string }];
    paths: {
      [name: string]: {
        [name: string]: OpenAPIMethod;
      };
    };
    components: {
      schemas: {
        [name: string]: {
          type?: string;
          description?: string;
          required?: any[];
          properties: {
            [name: string]: any;
          }
        }
      };
      securitySchemes: any;
      parameters?:any;
    }
    security?: any[];
    tags?: Array<{ name: string; description: string }>;
  }

  interface OpenAPIMethod {
    tags?: string[];
    description?: string;
    operationId: string;
    requestBody?: OpenAPIRequestBody;
    responses: OpenAPIMethodResponse;
    parameters?: OpenAPIParameter[];
    "x-codegen-request-body-name"?: string;
  }

  interface OpenAPIRequestBody {
    description:string;
    content: {
      [name: string]: {
        description?: string;
        schema: any;
        example?: any;
      }
    },
    required?: boolean;
  }

  interface OpenAPIMethodResponse {
    [name: string]: OpenAPIRequestBody;
  }

  interface OpenAPIParameter {
    name: string;
    description?: string;
    in: string;
    required: boolean;
    schema?: {
      type: string;
      format?: string;
      anyOf?: any[];
    };
    $ref?: string;
    enum?: string[];
    example?: any;
  }
  
  interface NewServiceProperty {
    propertyName: string;
    propertyDefinition: ServiceProperty;
  }
  
  interface NewServiceMethod {
    methodName: string;
    methodObject: string;
    methodDefinition: ServiceMethod;
  }

interface ServiceMethodMetaData {
    [name: string]: {
        httpMethod: string;
        httpPath: string;
    }
}

interface RefObjectMethod {
  $refObject:string; 
  k2method:ServiceMethodType;
  embeddedResponseObject:string;
}