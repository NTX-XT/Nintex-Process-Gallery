export class PostSchemaBuilderFromSwagger2 {
    constructor(
        public swaggerFile: SwaggerDefinition,
        public levelsToFlatten: number) {
        this.jsspPostSchema = {
            objects: {},
        };
        this.globalCounter = 0;
    }

    private jsspPostSchema: AbstractFolder;

    private globalCounter: number;

    public requiresAuth: boolean = false;

    public errors: string[] = [];

    describeSchema(): AbstractFolder {
        //let mySwagger = this.getDummySwagger(this.swaggerFile);
        let mySwagger = this.swaggerFile;

        for (const definition in mySwagger.definitions) {
            //enumerate all objects definitions

            let definitionProperties: NewServiceProperty[] = [];

            this.jsspPostSchema.objects[definition] = {
                displayName: definition,
                description: definition,
                properties: {},
                methods: {},
            };

            this.extractPropertiesForDefinition(
                definition,
                mySwagger.definitions,
                definitionProperties,
                "");

            for (const definitionProperty in definitionProperties) {
                //enumerate all properties for object
                this.jsspPostSchema.objects[definition].properties[
                    definitionProperties[definitionProperty].propertyName
                ] = definitionProperties[definitionProperty].propertyDefinition;
            }
        }

        let pathMethods: NewServiceMethod[] = [];

        for (const pathKey in mySwagger.paths) {
            //enumerate all paths
            if (mySwagger.paths.hasOwnProperty(pathKey)) {
                const path = mySwagger.paths[pathKey];
                let primaryPathObject: string = undefined;
                for (const methodKey in path) {
                    //enumerate http methods
                    if(path.hasOwnProperty("x-related-model")) {
                        primaryPathObject = (path["x-related-model"] as unknown) as string;
                    }
                    if (path.hasOwnProperty(methodKey) && this.methodKeyIsValid(methodKey)) {
                        const method = path[methodKey];
                        let newSRVMethod = this.buildServiceMethod(method, methodKey, pathKey, primaryPathObject);
                        //let newSRVMethod = this.buildServiceMethod(method, methodKey, pathKey);
                        if(newSRVMethod)    
                            pathMethods.push(newSRVMethod);
                    }
                }
            }
        }

        for (const authKey in mySwagger.securityDefinitions) {
            if (mySwagger.securityDefinitions.hasOwnProperty(authKey)) {
                this.requiresAuth = true;
            }
        }

        //Add UNPACK Methods for all JSON OBJECT/JSON OBJECT ARRAY Properties:
        for (const objkey in this.jsspPostSchema.objects) {
            if (this.jsspPostSchema.objects.hasOwnProperty(objkey)) {
                const serviceObject = this.jsspPostSchema.objects[objkey];
                for (const propkey in serviceObject.properties) {
                    let newServiceMethod: NewServiceMethod = undefined;
                    let methodObject:string = undefined;
                    if (serviceObject.properties.hasOwnProperty(propkey)) {
                        const serviceObjectProperty = serviceObject.properties[propkey];
                        if (
                            serviceObjectProperty.description.indexOf(
                                "***NEED_LIST_UNPACK_METHOD***") >= 0) {
                            methodObject = serviceObjectProperty.description.split(
                                    "|")[1];
                            newServiceMethod = this.buildUnPackServiceMethod(
                                    "list",
                                    methodObject);
                            serviceObjectProperty.description = `Call the Unpack JSON Object Array List Method on ${methodObject} to resolve`;
                        }
                        if (
                            serviceObjectProperty.description.indexOf(
                                "***NEED_READ_UNPACK_METHOD***") >= 0) {
                            methodObject = serviceObjectProperty.description.split(
                                    "|")[1];
                            newServiceMethod = this.buildUnPackServiceMethod(
                                    "read",
                                    methodObject);
                            serviceObjectProperty.description = `Call the Unpack JSON Object Read Method on ${methodObject} to resolve`;
                        }
                    }
                    if (newServiceMethod != undefined) {
                        pathMethods.push(newServiceMethod);
                        let newPackServiceMethod: NewServiceMethod = this.buildPackServiceMethod(methodObject);
                        pathMethods.push(newPackServiceMethod);
                    }
                        
                }
            }
        }

        //Add all methods to correct Sevice Object
        pathMethods.forEach((method) => {
            //console.log(`OBJECT = ${method.methodObject} | METHOD = ${method.methodName} | METHOD_TYPE = ${method.methodDefinition.type}`);
            if (this.jsspPostSchema.objects[method.methodObject] != undefined) {
                this.jsspPostSchema.objects[method.methodObject].methods[method.methodName] = method.methodDefinition;
            } else {
                //if we don't have an object, create one with List method which returns string only:
                this.jsspPostSchema.objects[method.methodObject] = {
                    displayName: method.methodObject,
                    description: method.methodObject,
                    properties: {
                        value: {
                            displayName: "Value",
                            type: "string",
                        },
                    },
                    methods: {}
                };
                this.jsspPostSchema.objects[method.methodObject].methods[method.methodName] = method.methodDefinition;

            }
            //console.log(`PostSchema has OBJECT? ${postSchema.objects[method.methodObject]===undefined?"NO":"YES"}`);
        });

        //Remove un-needed Service Objects:
        let objectsToBeRemoved: string[] = [];
        for (const objkey in this.jsspPostSchema.objects) {
            if (this.jsspPostSchema.objects.hasOwnProperty(objkey)) {
                const serviceObject = this.jsspPostSchema.objects[objkey];
                if (Object.keys(serviceObject.methods).length === 0 || Object.keys(serviceObject.properties).length === 0 || objkey === "undefined") {
                    //console.log(`${objkey} will be deleted!!`);
                    objectsToBeRemoved.push(objkey);
                }
            }
        }
        objectsToBeRemoved.forEach((element) => {
            delete this.jsspPostSchema.objects[element];
        });

        //ADD PACK Service Methods for Complex objects
        for (const objkey in this.jsspPostSchema.objects) {
            if (this.jsspPostSchema.objects.hasOwnProperty(objkey)) {
                const serviceObject = this.jsspPostSchema.objects[objkey];
                for (const methodKey in serviceObject.methods) {
                    if (serviceObject.methods.hasOwnProperty(methodKey)) {
                        if(methodKey === "UnpackJSONObject") {
                            this.jsspPostSchema.objects[objkey].properties["JSON.String"] = {
                                displayName: "Packed JSON Item",
                                type: "string",
                                extendedType: "k2.com/2019/memo"
                            }
                        }
                    }
                }
            }
        }

        return this.jsspPostSchema;
    }

    private methodKeyIsValid(m:string):boolean {
        switch (m.toLowerCase()) {
            case "get":
                return true;
            case "post":
                return true;
            case "put":
                return true;
            case "patch":
                return true;
            case "delete":
                return true;
            default:
                return false;
            }
    }

    private extractPropertiesForDefinition(
        swaggerDefinition,
        swaggerDefinitions,
        definitionProperties: NewServiceProperty[],
        propertyPrefix: string) {
        if (
            propertyPrefix === "" ||
            propertyPrefix.split(".").length < this.levelsToFlatten) {
            for (let property in swaggerDefinitions[swaggerDefinition].properties) {
                //enumerate properties
                let newProperty = this.buildServiceProperty(
                        property,
                        swaggerDefinitions[swaggerDefinition].properties[property],
                        definitionProperties,
                        swaggerDefinitions,
                        propertyPrefix);
                if (newProperty.propertyDefinition.type != undefined)
                    definitionProperties.push(newProperty);
            }
        }
    }

    private buildServiceProperty(
        swaggerPropertyName,
        swaggerProperty,
        definitionProperties: NewServiceProperty[],
        swaggerDefinitions,
        propertyPrefix: string): NewServiceProperty {
        let returnProperty: NewServiceProperty;
        let propType: string;
        let extendedPropType: string;
        let propName =
            (propertyPrefix != "" ? propertyPrefix + "." : "") + swaggerPropertyName;
        let childPropertyObjectName: string = undefined;
        let childPropertyObjectIsInArray: boolean = false;
        if (swaggerProperty.$ref == undefined) {
            switch (swaggerProperty.type) {
            case "boolean":
                propType = "boolean";
                break;
            case "string":
                propType = "string";
                break;
            case "integer":
                propType = "number";
                break;
            case "number":
                propType = "decimal";
                break;
            case "array":
                propType = "extendedString";
                extendedPropType = "k2.com/2019/memo";
                childPropertyObjectName =
                    swaggerProperty.items.$ref == undefined
                     ? swaggerProperty.items.type
                     : swaggerProperty.items.$ref.replace("#/definitions/", "");
                childPropertyObjectIsInArray = true;
                break;
            default:
                //propType = "UNDEFINED_OBJECT_" + swaggerProperty.type;
                propType = "extendedString";
                extendedPropType = "k2.com/2019/memo";
                break;
            }
        } else {
            //****if we are about to exceed flattening level add propery as a memo field which can hold JSON string
            childPropertyObjectName = swaggerProperty.$ref;
            childPropertyObjectName = childPropertyObjectName.replace(
                    "#/definitions/",
                    "");
            if (propName.split(".").length < this.levelsToFlatten) {
                this.extractPropertiesForDefinition(
                    childPropertyObjectName,
                    swaggerDefinitions,
                    definitionProperties,
                    propName);
            } else {
                propType = "extendedString";
                extendedPropType = "k2.com/2019/memo";
            }
        }

        let dispName: string = propName;
        let propDescrip: string = `${dispName} Value`;

        if (childPropertyObjectName != undefined) {
            if (childPropertyObjectIsInArray) {
                dispName = `${propName} is a JSON Object Array of ${childPropertyObjectName}`;
                propDescrip = `***NEED_LIST_UNPACK_METHOD***|${childPropertyObjectName}`;
            } else {
                dispName = `${propName} is a JSON Object of ${childPropertyObjectName}`;
                propDescrip = `***NEED_READ_UNPACK_METHOD***|${childPropertyObjectName}`;
            }
        }

        if (extendedPropType == undefined) {
            returnProperty = {
                propertyName: dispName,
                propertyDefinition: {
                    displayName: propName,
                    type: propType as ServiceValueType,
                    description: propDescrip,
                },
            };
        } else {
            returnProperty = {
                propertyName: propName,
                propertyDefinition: {
                    displayName: dispName,
                    type: propType as ServiceValueType,
                    extendedType: extendedPropType as ExtendedType,
                    description: propDescrip,
                },
            };
        }
        return returnProperty;
    }

    private buildServiceMethod(method: SwaggerMethod,methodKey: string,pathKey: string, primaryPathObject): NewServiceMethod {
        let newServiceMethod: NewServiceMethod = {
            methodName: undefined,
            methodObject: undefined,
            methodDefinition: {
                displayName: method.operationId,
                //description: `${methodKey}|${pathKey}`,
                type: "list",
                inputs: [],
                requiredInputs: [],
                parameters: {},
                requiredParameters: [],
                outputs: [],
            },
        };

        newServiceMethod.methodName = method.operationId;

        try {
            let httpResponseCode = method.responses.hasOwnProperty("200") ? "200" : method.responses.hasOwnProperty("201") ? "201" : "204";
            if (method.responses.hasOwnProperty(httpResponseCode)) { //for now we only handle 200/201
                //Link method to the correct Service Object based on Response and Parameters
                let httpResponse = method.responses[httpResponseCode];
                if (httpResponse.hasOwnProperty("schema") && httpResponse.schema["type"] === "array") {
                    if (httpResponse.schema.items["$ref"] != undefined) {
                        newServiceMethod.methodObject = httpResponse.schema.items[
                                "$ref"
                            ].replace("#/definitions/", "");
                        primaryPathObject = newServiceMethod.methodObject;
                    } else {
                        newServiceMethod.methodObject = primaryPathObject;
                        if (newServiceMethod.methodObject === undefined) {
                            let pathParts = pathKey.split("/");
                            newServiceMethod.methodObject = pathParts[pathParts.length - 1];
                        }
                    }
                    newServiceMethod.methodDefinition.type = "list";
                } else {
                    if (methodKey != "delete" && httpResponse.hasOwnProperty("schema") && httpResponse.schema["$ref"] != undefined) {
                        newServiceMethod.methodObject = httpResponse.schema["$ref"].replace(
                                "#/definitions/",
                                "");
                        primaryPathObject = newServiceMethod.methodObject;
                    }
    
                    switch (methodKey) {
                    case "get":
                        newServiceMethod.methodDefinition.type = "read";
                        break;
                    case "post":
                        newServiceMethod.methodDefinition.type = "create";
                        break;
                    case "put":
                        newServiceMethod.methodDefinition.type = "update";
                        break;
                    case "patch":
                        newServiceMethod.methodDefinition.type = "update";
                        break;
                    case "delete":
                        newServiceMethod.methodObject = primaryPathObject === undefined ? httpResponse.schema["$ref"].replace("#/definitions/", "") : primaryPathObject;
                        newServiceMethod.methodDefinition.type = "delete";
                        break;
                    default:
                        break;
                    }
                }

                //add Outputs based on httpResponse = method.responses["200"];
                if (httpResponse.hasOwnProperty("schema") && httpResponse.schema["type"] === "array") {
                    if (httpResponse.schema.items["$ref"] != undefined) {
                        let objectInOutput = httpResponse.schema.items["$ref"].replace(
                                "#/definitions/",
                                "");
                        //NOTE: Depending on level of flattening, RAW JSON can be pushed into a MEMO Field for later UNPACKING
                        newServiceMethod.methodDefinition.outputs = this.objPropertiesToArray(
                                this.jsspPostSchema.objects[objectInOutput].properties);
                    } else {
                        newServiceMethod.methodDefinition.outputs.push("Value");
                    }
                } else {
                    if (methodKey != "delete" && httpResponse.hasOwnProperty("schema") && httpResponse.schema["$ref"] != undefined) {
                        let objectInOutput = httpResponse.schema["$ref"].replace(
                                "#/definitions/",
                                "");
                        newServiceMethod.methodDefinition.outputs = this.objPropertiesToArray(
                                this.jsspPostSchema.objects[objectInOutput].properties);
                    }
                }
    
            }
            else 
            {
                newServiceMethod = undefined;
            }
            //Add Parameters / Inputs
            //get or delete --> Parameters
            //post or put --> Inputs
    
            if (method.parameters != undefined) {
                method.parameters.forEach((parameter) => {
                    this.globalCounter++;
                    let paramObject = parameter;
                    if(paramObject.$ref != undefined)  { //specified under swagger parameters section
                        let parameRefName = paramObject.$ref.replace("#/parameters/","");
                        paramObject = this.swaggerFile.parameters[parameRefName];
                    }
                    if (paramObject.type === undefined) {
                        newServiceMethod.methodObject = paramObject.schema.$ref.replace("#/definitions/","");
                        newServiceMethod.methodDefinition.inputs = this.objPropertiesToArray(this.jsspPostSchema.objects[newServiceMethod.methodObject].properties);
                    } else {
                        let k2Type:ServiceValueType = "string";
                        switch (paramObject.type) {
                            case "integer":
                                k2Type = "number";
                                break;
                            case "number":
                                k2Type = "decimal";
                                break;
                            case "boolean":
                                    k2Type = "boolean";
                                    break;
                            default:
                                k2Type = "string"
                                break;
                        }
                        newServiceMethod.methodDefinition.parameters[paramObject.name] = {
                            displayName: paramObject.name,
                            type: k2Type,
                        };
                    }
                    if (paramObject.required && paramObject.type != undefined) {
                        newServiceMethod.methodDefinition.requiredParameters.push(
                            paramObject.name);
                    }
                });
            }



            if(newServiceMethod.methodName === undefined) {
                newServiceMethod.methodName = newServiceMethod.methodDefinition.type+newServiceMethod.methodObject;
            }

            newServiceMethod.methodDefinition.data = {
                httpMethod: methodKey,
                httpPath: pathKey
            }

            //handle 'functions' in URL and string params
            for (const paramKey in newServiceMethod.methodDefinition.parameters) {
                if(newServiceMethod.methodDefinition.parameters[paramKey].type === "string") {
                    newServiceMethod.methodDefinition.data.httpPath = newServiceMethod.methodDefinition.data.httpPath.replace(`({${paramKey}})`,`('{${paramKey}}')`);
                }
            }

        } catch (error) {
            this.errors.push(`Error with buildServiceMethod(${method}, ${methodKey}, ${pathKey}): ${error}`);
            newServiceMethod = undefined;
        }

        return newServiceMethod;
    }

    private buildUnPackServiceMethod(
        methodType: ServiceMethodType,
        methodObject: string): NewServiceMethod {
        //methodObject here is actually the property which contains the name of the Object
        //e.g. address.Geo --> Geo is the object
        if (methodObject === "string") {
            return undefined;
        }

        try {
            let newServiceMethod: NewServiceMethod = {
                methodName: `UnpackJSON${
          methodType == "list" ? "ObjectArray" : "Object"
        }`,
                methodObject: methodObject,
                methodDefinition: {
                    displayName: `Unpack JSON ${
            methodType == "list" ? "Object Array" : "Object"
          }`,
                    type: methodType,
                    inputs: [],
                    requiredInputs: [],
                    parameters: {
                        "JSON.String.Param": {
                            displayName: `JSON ${methodObject} ${
                methodType == "list" ? "Object Array" : "Object"
              } String`,
                            description: "JSON String",
                            type: "string",
                            extendedType: "k2.com/2019/memo",
                        },
                    },
                    requiredParameters: ["JSON.String.Param"],
                    outputs: this.objPropertiesToArray(
                        this.jsspPostSchema.objects[methodObject].properties),
                },
            };
            return newServiceMethod;
        } catch (error) {
            console.log(
`Error in: buildUnPackServiceMethod(${methodType}, ${methodObject})`);
            return undefined;
        }
    }


    private buildPackServiceMethod(
        //methodType: ServiceMethodType,
        methodObject: string): NewServiceMethod {
        //methodObject here is actually the property which contains the name of the Object
        //e.g. address.Geo --> Geo is the object
        if (methodObject === "string") {
            return undefined;
        }

        try {
            // this.jsspPostSchema.objects[methodObject].properties["JSON.String"] = {
            //     displayName: "Packed JSON Item",
            //     type: "string",
            //     extendedType: "k2.com/2019/memo"
            // }
            let newServiceMethod: NewServiceMethod = {
                methodName: "PackJSONObject",
                methodObject: methodObject,
                methodDefinition: {
                    displayName: "Pack JSON Object",
                    type: "read",
                    inputs: this.objPropertiesToArray(this.jsspPostSchema.objects[methodObject].properties),
                    outputs: ["JSON.String"],
                },
            };
            return newServiceMethod;
        } catch (error) {
            console.log(`Error in: buildPackServiceMethod(${methodObject})`);
            return undefined;
        }
    }

    private objPropertiesToArray(objProperties: {
        [name: string]: ServiceProperty;
    }): string[]{
        let newArray: string[] = [];
        for (const propKey in objProperties) {
            if (objProperties.hasOwnProperty(propKey)) {
                newArray.push(propKey);
            }
        }
        return newArray;
    }
}

