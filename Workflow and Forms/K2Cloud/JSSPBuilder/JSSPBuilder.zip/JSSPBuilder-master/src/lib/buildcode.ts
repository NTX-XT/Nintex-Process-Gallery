export class TSCodeBuilder {
    constructor(
        public postSchema:AbstractFolder,
        public metaData: BrokerMetadata,
        public levelsToFlatten: number,
        public anonymous: boolean) {
    }

    buildTypeScriptFile():string {
        let casesForObject:string = "";

        for (const objectKey in this.postSchema.objects) {
            casesForObject+=`case "${objectKey}": await onexecute${objectKey.replace(/ /g,"_").replace(/\./g,"_")}(methodName, parameters, properties, configuration); break;\n`;
        }

        let objectExecuteFunctions:string = "";

        for (const objectKey in this.postSchema.objects) {
            if (this.postSchema.objects.hasOwnProperty(objectKey)) {
                const object = this.postSchema.objects[objectKey];
                objectExecuteFunctions+=`async function onexecute${objectKey.replace(/ /g,"_").replace(/\./g,"_")}(methodName: string, parameters: SingleRecord, properties: SingleRecord, configuration: SingleRecord): Promise<void> {
                switch (methodName) {`;
                for (const methodkey in object.methods) {
                    if (object.methods.hasOwnProperty(methodkey)) {
                    const method = object.methods[methodkey];
                    objectExecuteFunctions+=`case "${methodkey}": await onexecute${objectKey.replace(/ /g,"_").replace(/\./g,"_")}${methodkey.replace(/ /g,"_").replace(/\./g,"_")}(parameters, properties, configuration); break;`;
                    }
                }
                objectExecuteFunctions+=` default: throw new Error("The method " + methodName + " is not supported.");
                                        }
                                    }`;
            }
        }

        let objectExecuteMethodFunctions:string = "";
        for (const objectKey in this.postSchema.objects) {
            if (this.postSchema.objects.hasOwnProperty(objectKey)) {
                const object = this.postSchema.objects[objectKey];
                for (const methodkey in object.methods) {
                    if (object.methods.hasOwnProperty(methodkey)) {
                        const method = object.methods[methodkey];
                        if(method.data != undefined) {
                            let http_path: string = "`"+method.data.httpPath+"`";
                            for (const paramkey in method.parameters) {
                                if(http_path.indexOf(paramkey) >= 0) {
                                    http_path = http_path.replace(`{${paramkey}}`,"${encodeURIComponent(parameters['"+paramkey+"'] as string)}");
                                }
                            }
                            let addFilterFunc = false;
                            addFilterFunc = method.type === "list" && method.parameters && method.parameters.hasOwnProperty("$filter");
                            objectExecuteMethodFunctions+=this.buildExecuteFunction(objectKey.replace(/ /g,"_").replace(/\./g,"_"),methodkey.replace(/ /g,"_").replace(/\./g,"_"),method.data.httpMethod,http_path,method.data.httpResponseObject,addFilterFunc);
                        }
                        else {
                            //PackJSONObject | UnpackJSONObject
                            //debug start
                            if(methodkey != "UnpackJSONObject" && methodkey != "UnpackJSONObjectArray" && methodkey != "PackJSONObject") {
                                console.error(`We have a missing method for ${objectKey} ${methodkey}`);
                            }
                            //debug end
                            if(methodkey === "UnpackJSONObject")
                                objectExecuteMethodFunctions+=this.buildUnpackExecuteFunction(`${objectKey.replace(/ /g,"_").replace(/\./g,"_")}${methodkey}`);
                            if(methodkey === "UnpackJSONObjectArray")
                                objectExecuteMethodFunctions+=this.buildUnpackArrayExecuteFunction(`${objectKey.replace(/ /g,"_").replace(/\./g,"_")}${methodkey}`);                                
                            if(methodkey === "PackJSONObject")
                                objectExecuteMethodFunctions+=this.buildPackExecuteFunction(`${objectKey.replace(/ /g,"_").replace(/\./g,"_")}${methodkey}`);
                        }
                    }
                }
            }
        }

        let myCode:string = 
        `//Generated with the K2JSSPGenerator tool
        
        import '@k2oss/k2-broker-core';

        metadata = ${JSON.stringify(this.metaData)}

        ondescribe = async function ({ configuration }): Promise<void> {
                postSchema(${JSON.stringify(this.postSchema)}
        )};

        onexecute = async function ({ objectName, methodName, parameters, properties, configuration }): Promise<void> {
            switch (objectName) {
                ${casesForObject}
                default: throw new Error("The object " + objectName + " is not supported.");
            }
        }
        
        ${objectExecuteFunctions}
        
        ${objectExecuteMethodFunctions}
        
        ${this.buildUtilityFunctions()}
        `;

        

        return myCode;

    }

    private buildExecuteFunction(objectKey: string, methodKey: string, httpMethod: string, httpPath: string, returnObject: string, addFilterFunc:boolean):string {
        let functionName:string = `${objectKey.replace(/ /g,"_").replace(/\./g,"_")}${methodKey.replace(/ /g,"_").replace(/\./g,"_")}`;
        switch (httpMethod.toLowerCase()) {
            case 'post':
                return this.buildPostExecuteFunction(functionName, httpMethod, httpPath, returnObject);
                
            case 'put':
                return this.buildPostExecuteFunction(functionName, httpMethod, httpPath, returnObject);
                
            case 'patch':
                return this.buildPostExecuteFunction(functionName, httpMethod, httpPath, returnObject);
                    ``
            default:
                return this.buildGetExecuteFunction(functionName, httpMethod, httpPath, returnObject, addFilterFunc);
        }
    }

    private buildGetExecuteFunction(funcName: string, httpMethod: string, httpPath: string, returnObject, addFilterFunc: boolean): string {
        return `function onexecute${funcName}(parameters: SingleRecord, properties: SingleRecord, configuration: SingleRecord): Promise<void> {
            return new Promise<void>((resolve, reject) => {
                let urlValue = configuration["ServiceURL"] as string;
                let httpPath = ${httpPath};
                ${addFilterFunc?"httpPath += buildXtraParams(httpPath, parameters, properties);":""}
                let xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function () {
                    try {
                        if (xhr.readyState !== 4) return;
                        if (xhr.status !== 200) throw new Error("Failed with status " + xhr.status);
                        let  obj = JSON.parse(xhr.responseText);
                        let unpackedObject:any = {};
                        let executeResult: ExecuteResult = unpackObject(obj${returnObject && returnObject!=""?"."+returnObject:""},"", unpackedObject);
                        postResult(executeResult);
                        resolve();
                    } catch (error) {
                        reject(error);
                    }
                }
                urlValue = urlValue.endsWith("/") ? urlValue : urlValue + "/";
                httpPath = httpPath.startsWith("/") ? httpPath.substr(1) : httpPath + "/";
                ${this.anonymous===true?"":" xhr.withCredentials = true;"}
                xhr.open("${httpMethod}", urlValue + httpPath);
                xhr.send();
            });
            }`
    }

    private buildPostExecuteFunction(funcName: string, httpMethod: string, httpPath: string, returnObject: string): string {
        return `function onexecute${funcName}(parameters: SingleRecord, properties: SingleRecord, configuration: SingleRecord): Promise<void> {
            return new Promise<void>((resolve, reject) => {
                let urlValue = configuration["ServiceURL"] as string;
                let httpPath = ${httpPath};
                let parsedData = parseInputObject(properties); //pull objects out of stringified object properties
                let packedData = unflattenObject(parsedData); //turn dot notation flattened properties into objects
                let data = JSON.stringify(packedData);

                let xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function () {
                    try {
                        if (xhr.readyState !== 4) return;
                        if (xhr.status !== 200 && xhr.status !== 201) throw new Error("Failed with status " + xhr.status);
                        let obj = JSON.parse(xhr.responseText);
                        let unpackedObject:any = {};
                        let executeResult: ExecuteResult = unpackObject(obj${returnObject && returnObject!=""?"."+returnObject:""},"", unpackedObject);
                        postResult(executeResult);
                        resolve();
                    } catch (error) {
                        reject(error);
                    }
                }
                urlValue = urlValue.endsWith("/") ? urlValue : urlValue + "/";
                httpPath = httpPath.startsWith("/") ? httpPath.substr(1) : httpPath + "/";
                ${this.anonymous===true?"":" xhr.withCredentials = true;"}
                xhr.open("${httpMethod}", urlValue + httpPath);
                xhr.setRequestHeader("Content-Type", "application/json");
                xhr.send(data);
            });
            }`
    }

    private buildUnpackExecuteFunction(funcName: string): string {
        return `function onexecute${funcName}(parameters: SingleRecord, properties: SingleRecord, configuration: SingleRecord): Promise<void> {
            return new Promise<void>((resolve, reject) => {
                try {
                    let obj = JSON.parse(parameters["JSON.String.Param"] as string);
                    for (const propKey in obj) {
                        if (obj.hasOwnProperty(propKey)) {
                            const prop = obj[propKey];    
                            if(typeof(prop) == "object")
                                obj[propKey] = JSON.stringify(obj[propKey]);
                        }
                    }
                    postResult(obj);
                    resolve();
                } catch (error) {
                    reject(error);
                }
            });
            }`
    }

    private buildUnpackArrayExecuteFunction(funcName: string): string {
        return `function onexecute${funcName}(parameters: SingleRecord, properties: SingleRecord, configuration: SingleRecord): Promise<void> {
            return new Promise<void>((resolve, reject) => {
                try {
                    let objArray = JSON.parse(parameters["JSON.String.Param"] as string);
                    objArray.forEach(obj => {
                        for (const propKey in obj) {
                            if (obj.hasOwnProperty(propKey)) {
                                const prop = obj[propKey];
                                if (typeof(prop) == "object")
                                    obj[propKey] = JSON.stringify(obj[propKey]);
                            }
                        }
                    });
                    postResult(objArray); 
                    resolve(); 
                } catch (error) {
                    reject(error);
                }
            });
            }`
    }

    private buildPackExecuteFunction(funcName: string): string {
        return `function onexecute${funcName}(parameters: SingleRecord, properties: SingleRecord, configuration: SingleRecord): Promise<void> {
            return new Promise<void>((resolve, reject) => {
                try {
                    let obj = { 
                        "JSON.String": JSON.stringify(properties)
                    }
                    postResult(obj);
                    resolve();
                } catch (error) {
                    reject(error);
                }
            });
            }`
    }

    private buildUtilityFunctions(): string {
        return `
        function unpackObject(sourceObject:any, propPrefix:string, unpackedObject: any):ExecuteResult {
            if(sourceObject.length > 0) {
              unpackedObject = sourceObject.map(x => {
                let unpackedSingleObject: any = {};
                flattenProperties(x, propPrefix, unpackedSingleObject);
                return unpackedSingleObject;
              });
            }
            else
            {
              flattenProperties(sourceObject, propPrefix, unpackedObject);
            }
            return unpackedObject;
        }

        function flattenProperties(xSourceObject:any, propPrefix:string, unpackedObject: any):void {
            for (const propKey in xSourceObject) {
              if (xSourceObject.hasOwnProperty(propKey)) {
                const prop = xSourceObject[propKey];   
                let propName = (propPrefix != "" ? propPrefix + "." : "") + propKey; 
                if(typeof(prop) == "object" && prop != null && prop != undefined) {
                  if (prop.length === undefined && propName.split(".").length < ${this.levelsToFlatten}) {
                    unpackObject(prop, propName, unpackedObject);
                  }
                  else {
                    unpackedObject[propName] = JSON.stringify(xSourceObject[propKey]);
                  }
                }
                else 
                {
                  unpackedObject[propName] = xSourceObject[propKey];
                }
              }
            }
        }
        
        function parseInputObject(object:any):any {
            for (const propKey in object) {
              if (object.hasOwnProperty(propKey)) {
                const value = object[propKey];
                try {
                  object[propKey] = JSON.parse(value);
                  if(typeof(object[propKey]) === "object") {
                    parseInputObject(object[propKey]);
                  }
                } 
                catch (error) {
                  object[propKey] = value;
                }
              }
            }
            return object
        }

        function unflattenObject(inputObject:any): any {
            let unflattenedObject:any = {};
            for (const propName in inputObject) {
              if (inputObject.hasOwnProperty(propName)) {
                const propValue = inputObject[propName];
                if(propName.indexOf(".") > 0) { //we have a flattened property - build object
                  let propObjectComponents = propName.split(".");
                  //unflattenedObject[propName[0]] = unflattenProperty(propValue);
                  unflattenedObject[propObjectComponents[0]] = buildObject(unflattenedObject[propObjectComponents[0]], propName.replace(${"`${propObjectComponents[0]}.`"},""), propValue);
                } else {
                  unflattenedObject[propName] = propValue;
                }
              }
            }
            return unflattenedObject;
          }
        
          function buildObject(currentObject:any, propName:string, propValue: any): any {
            if(currentObject === undefined || currentObject === null) {
              currentObject = {};
            }
            if(propName.indexOf(".") > 0 ) {
              let propObjectComponents = propName.split(".");
              currentObject[propObjectComponents[0]] = buildObject(currentObject[propObjectComponents[0]], propName.replace(${"`${propObjectComponents[0]}.`"},""), propValue);
            }  
            else {
              currentObject[propName] = propValue;
            }
            return currentObject;
          } 

          function buildXtraParams(pathUrl: string, parameters: SingleRecord, properties: SingleRecord): string {
            let andFilter = "";
            for (const propKey in properties) {
                if (properties.hasOwnProperty(propKey)) {
                    const element = properties[propKey];
                    if(element && (typeof(element) === "bigint" || typeof(element) === "boolean" || typeof(element) === "number" )) {
                    andFilter+=${"` and ${propKey} eq ${element}`"};
                    }
                    else if(element && typeof(element) != "undefined") {
                    andFilter+=${"` and ${propKey} eq '${element}'`"};
                    }
                }
            }
        
            let xtraParams = "";
        
            if(parameters && parameters.$filter && parameters.$filter != "" || andFilter != "") {
                xtraParams = pathUrl.indexOf("?") > 0?"&$filter=":"?$filter=";
            }
        
            if(parameters && parameters.$filter && parameters.$filter) {
                xtraParams+=${"`(${parameters.$filter})`"};
            }
        
            if(andFilter != "") {
                xtraParams+=andFilter;
            }
        
            xtraParams = xtraParams.replace("$filter= and","$filter=");
        
            for (const paramKey in parameters) {
                if (paramKey === "$select" || paramKey === "$top" || paramKey === "$skip" || paramKey === "$orderby") {
                    const paramValue = parameters[paramKey];
                    if(paramValue && paramValue != "") {
                        xtraParams += ${"`${xtraParams.indexOf('?') >= 0?'&':'?'}${paramKey}=${paramValue}`"};
                    }
                    
                }
            }
        
            return xtraParams;
        }
        `
    }


}