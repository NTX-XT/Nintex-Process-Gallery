export class PostSchemaBuilderFromOpenAPI3 {
    constructor(
        public openapiFile: OpenAPIDefinition,
        public levelsToFlatten: number) {
        this.jsspPostSchema = {
            objects: {},
        };
        this.globalCounter = 0;
    }

    private jsspPostSchema: AbstractFolder;

    private globalCounter: number;

    public requiresAuth: boolean = false;

    public errors: string[] = [];

    describeSchema(): AbstractFolder {
        let myOpenApi = this.openapiFile;

        let openApiSchemas = myOpenApi.components.schemas;

        for (const definition in openApiSchemas) {
            //enumerate all objects definitions

            let definitionProperties: NewServiceProperty[] = [];

            this.jsspPostSchema.objects[definition] = {
                displayName: definition,
                description: definition,
                properties: {},
                methods: {},
            };

            this.extractPropertiesForDefinition(
                definition,
                openApiSchemas,
                definitionProperties,
                "");

            for (const definitionProperty in definitionProperties) {
                //enumerate all properties for object
                this.jsspPostSchema.objects[definition].properties[
                    definitionProperties[definitionProperty].propertyName
                ] = definitionProperties[definitionProperty].propertyDefinition;
            }
        }

        let pathMethods: NewServiceMethod[] = [];

        for (const pathKey in myOpenApi.paths) {
            //enumerate all paths
            if (myOpenApi.paths.hasOwnProperty(pathKey)) {
                const path = myOpenApi.paths[pathKey];
                let primaryPathObject: string = undefined;
                for (const methodKey in path) {
                    //enumerate http methods
                    if (path.hasOwnProperty(methodKey) && this.methodKeyIsValid(methodKey)) {
                        const method = path[methodKey];
                        let newSRVMethod = this.buildServiceMethod(method, methodKey, pathKey);
                        if(newSRVMethod)    
                            pathMethods.push(newSRVMethod);
                    }
                }
            }
        }

        for (const authKey in myOpenApi.components.securitySchemes) {
            if (myOpenApi.components.securitySchemes.hasOwnProperty(authKey)) {
                this.requiresAuth = true;
            }
        }

        //Add UNPACK Methods for all JSON OBJECT/JSON OBJECT ARRAY Properties:
        for (const objkey in this.jsspPostSchema.objects) {
            if (this.jsspPostSchema.objects.hasOwnProperty(objkey)) {
                const serviceObject = this.jsspPostSchema.objects[objkey];
                for (const propkey in serviceObject.properties) {
                    let newServiceMethod: NewServiceMethod = undefined;
                    let methodObject:string = undefined;
                    if (serviceObject.properties.hasOwnProperty(propkey)) {
                        const serviceObjectProperty = serviceObject.properties[propkey];
                        if (
                            serviceObjectProperty.description.indexOf(
                                "***NEED_LIST_UNPACK_METHOD***") >= 0) {
                            methodObject = serviceObjectProperty.description.split(
                                    "|")[1];
                            newServiceMethod = this.buildUnPackServiceMethod(
                                    "list",
                                    methodObject);
                            serviceObjectProperty.description = `Call the Unpack JSON Object Array List Method on ${methodObject} to resolve`;
                        }
                        if (
                            serviceObjectProperty.description.indexOf(
                                "***NEED_READ_UNPACK_METHOD***") >= 0) {
                            methodObject = serviceObjectProperty.description.split(
                                    "|")[1];
                            newServiceMethod = this.buildUnPackServiceMethod(
                                    "read",
                                    methodObject);
                            serviceObjectProperty.description = `Call the Unpack JSON Object Read Method on ${methodObject} to resolve`;
                        }
                    }
                    if (newServiceMethod != undefined) {
                        pathMethods.push(newServiceMethod);
                        let newPackServiceMethod: NewServiceMethod = this.buildPackServiceMethod(methodObject);
                        pathMethods.push(newPackServiceMethod);
                    }
                        
                }
            }
        }

        //Add all methods to correct Sevice Object
        pathMethods.forEach((method) => {
            if (this.jsspPostSchema.objects[method.methodObject] != undefined) {
                this.jsspPostSchema.objects[method.methodObject].methods[
                    method.methodName
                ] = method.methodDefinition;
            } else {
                //if we don't have an object, create one with List method which returns string only:
                this.jsspPostSchema.objects[method.methodObject] = {
                    displayName: method.methodObject,
                    description: method.methodObject,
                    properties: {
                        value: {
                            displayName: "Value",
                            type: "string",
                        },
                    },
                    methods: {}
                };
                this.jsspPostSchema.objects[method.methodObject].methods[method.methodName] = method.methodDefinition;
            }
        });

        //Remove un-needed Service Objects:
        let objectsToBeRemoved: string[] = [];
        for (const objkey in this.jsspPostSchema.objects) {
            if (this.jsspPostSchema.objects.hasOwnProperty(objkey)) {
                const serviceObject = this.jsspPostSchema.objects[objkey];
                if (Object.keys(serviceObject.methods).length === 0 || Object.keys(serviceObject.properties).length === 0 || objkey === "undefined") {
                    objectsToBeRemoved.push(objkey);
                }
            }
        }
        objectsToBeRemoved.forEach((element) => {
            delete this.jsspPostSchema.objects[element];
        });

        //ADD PACK Service Methods for Complex objects
        for (const objkey in this.jsspPostSchema.objects) {
            if (this.jsspPostSchema.objects.hasOwnProperty(objkey)) {
                const serviceObject = this.jsspPostSchema.objects[objkey];
                for (const methodKey in serviceObject.methods) {
                    if (serviceObject.methods.hasOwnProperty(methodKey)) {
                        if(methodKey === "UnpackJSONObject") {
                            this.jsspPostSchema.objects[objkey].properties["JSON.String"] = {
                                displayName: "Packed JSON Item",
                                type: "string",
                                extendedType: "k2.com/2019/memo"
                            }
                        }
                    }
                }
            }
        }

        //console.log(this.jsspPostSchema);
        //console.log(JSON.stringify(this.jsspPostSchema));
        //delete this.jsspPostSchema.objects.undefined;

        return this.jsspPostSchema;
    }

    private methodKeyIsValid(m:string):boolean {
        switch (m.toLowerCase()) {
            case "get":
                return true;
            case "post":
                return true;
            case "put":
                return true;
            case "patch":
                return true;
            case "delete":
                return true;
            default:
                return false;
            }
    }

    private extractPropertiesForDefinition(
        openapiDefinition,
        openapiDefinitions,
        definitionProperties: NewServiceProperty[],
        propertyPrefix: string) {
        if (
            propertyPrefix === "" ||
            propertyPrefix.split(".").length < this.levelsToFlatten) {
            for (let property in openapiDefinitions[openapiDefinition].properties) {
                //enumerate properties
                let newProperty = this.buildServiceProperty(
                        property,
                        openapiDefinitions[openapiDefinition].properties[property],
                        definitionProperties,
                        openapiDefinitions,
                        propertyPrefix);
                if (newProperty && newProperty.propertyDefinition.type)
                    definitionProperties.push(newProperty);
            }
        }
    }

    private buildServiceProperty(
        openapiPropertyName,
        openapiProperty,
        definitionProperties: NewServiceProperty[],
        openapiDefinitions,
        propertyPrefix: string): NewServiceProperty {
        let returnProperty: NewServiceProperty;
        let propType: string;
        let extendedPropType: string;
        let propName =
            (propertyPrefix != "" ? propertyPrefix + "." : "") + openapiPropertyName;
        let childPropertyObjectName: string = undefined;
        let childPropertyObjectIsInArray: boolean = false;

        try {
            let propertyReference = openapiProperty.$ref || (openapiProperty.hasOwnProperty("anyOf") ? openapiProperty.anyOf[0].$ref : undefined);
            //if (openapiProperty.$ref == undefined) {
            if (propertyReference == undefined) {
                switch (openapiProperty.type) {
                case "boolean":
                    propType = "boolean";
                    break;
                case "string":
                    propType = "string";
                    break;
                case "integer":
                    propType = "number";
                    break;
                case "number":
                    propType = "decimal";
                    break;
                case "array":
                    propType = "extendedString";
                    extendedPropType = "k2.com/2019/memo";

                    let propertyReferenceInArray = openapiProperty.items.$ref || (openapiProperty.items.hasOwnProperty("anyOf") ? openapiProperty.items.anyOf[0].$ref : undefined);

                    childPropertyObjectName = propertyReferenceInArray == undefined ? openapiProperty.items.type : propertyReferenceInArray.replace("#/components/schemas/", "");
                    childPropertyObjectIsInArray = true;
                    break;
                default:
                    //propType = "UNDEFINED_OBJECT_" + openapiProperty.type;
                    propType = "extendedString";
                    extendedPropType = "k2.com/2019/memo";
                    break;
                }
            } else {
                //****if we are about to exceed flattening level add propery as a memo field which can hold JSON string
                childPropertyObjectName = propertyReference //openapiProperty.$ref;
                childPropertyObjectName = childPropertyObjectName.replace(
                        "#/components/schemas/",
                        "");
                if (propName.split(".").length < this.levelsToFlatten) {
                    this.extractPropertiesForDefinition(
                        childPropertyObjectName,
                        openapiDefinitions,
                        definitionProperties,
                        propName);
                } else {
                    propType = "extendedString";
                    extendedPropType = "k2.com/2019/memo";
                }
            }

            let dispName: string = propName;
            let propDescrip: string = `${dispName} Value`;

            if (childPropertyObjectName != undefined && childPropertyObjectName != "string" && childPropertyObjectName != "array") {
                if (childPropertyObjectIsInArray) {
                    dispName = `${propName} is a JSON Object Array of ${childPropertyObjectName}`;
                    propDescrip = `***NEED_LIST_UNPACK_METHOD***|${childPropertyObjectName}`;
                } else {
                    dispName = `${propName} is a JSON Object of ${childPropertyObjectName}`;
                    propDescrip = `***NEED_READ_UNPACK_METHOD***|${childPropertyObjectName}`;
                }
            }

            if (extendedPropType == undefined) {
                returnProperty = {
                    propertyName: dispName,
                    propertyDefinition: {
                        displayName: propName,
                        type: propType as ServiceValueType,
                        description: propDescrip,
                    },
                };
            } else {
                returnProperty = {
                    propertyName: propName,
                    propertyDefinition: {
                        displayName: dispName,
                        type: propType as ServiceValueType,
                        extendedType: extendedPropType as ExtendedType,
                        description: propDescrip,
                    },
                };
            }
        } catch (error) {
            this.errors.push(`Error with buildServiceProperty(${openapiPropertyName}): ${error}`);
            returnProperty = undefined;
        }    

        
        return returnProperty;
    }

    private buildServiceMethod(
        method: OpenAPIMethod,
        methodKey: string,
        pathKey: string): NewServiceMethod {
        let primaryPathObject: string = undefined;

        let newServiceMethod: NewServiceMethod = {
            methodName: undefined,
            methodObject: undefined,
            methodDefinition: {
                displayName: method.operationId,
                type: "list",
                inputs: [],
                requiredInputs: [],
                parameters: {},
                requiredParameters: [],
                outputs: [],
            },
        };

        newServiceMethod.methodName = method.operationId;

        try {
            let embeddedResponseObject = "";
            let httpResponseCode = method.responses.hasOwnProperty("200") ? "200" : method.responses.hasOwnProperty("201") ? "201" : "204";
            //for delete: not sure how to link to K2 Object?
            if (method.responses.hasOwnProperty(httpResponseCode) && method.responses[httpResponseCode].hasOwnProperty("content")) { //for now we only handle 200/201
                let httpResponse = method.responses[httpResponseCode].content["application/json"] || method.responses[httpResponseCode].content["text/json"] || method.responses[httpResponseCode].content["application/octet-stream"];    
                if(httpResponse === undefined) {
                    throw new Error(`No application/json response was found for ${methodKey} on ${method.operationId}`);
                }
        
                //let $refObject = "#/components/schemas/Microsoft.OData.Service.Sample.TrippinInMemory.Models.Airline";
                //let k2MethodType = "list";
                

                let refObjectAndMethod = this.getRefObject(httpResponse.schema, methodKey);
                let $refObject = refObjectAndMethod.$refObject;
                newServiceMethod.methodDefinition.type = refObjectAndMethod.k2method;
                embeddedResponseObject = refObjectAndMethod.embeddedResponseObject;

                //handle the return object:
                if($refObject) {
                    newServiceMethod.methodObject = $refObject;
                    primaryPathObject = newServiceMethod.methodObject;
                    newServiceMethod.methodDefinition.outputs = this.objPropertiesToArray(this.jsspPostSchema.objects[newServiceMethod.methodObject].properties);
                } else {
                    newServiceMethod.methodObject = primaryPathObject;
                    if (newServiceMethod.methodObject === undefined) {
                        let pathParts = pathKey.split("/");
                        newServiceMethod.methodObject = pathParts[pathParts.length - 1];
                        newServiceMethod.methodObject = newServiceMethod.methodObject.split("(")[0];
                    }
                    newServiceMethod.methodDefinition.outputs.push("Value");
                }

                //handle the input object:
                if (method.requestBody != undefined) { //object in body for post
                    let content = method.requestBody.content["application/json"] || method.requestBody.content["text/json"];
                    if(content && content.schema.$ref) {
                        newServiceMethod.methodObject = content.schema.$ref.replace("#/components/schemas/","");
                        newServiceMethod.methodDefinition.inputs = this.objPropertiesToArray(this.jsspPostSchema.objects[newServiceMethod.methodObject].properties);
                    }
                    else {
                        this.errors.push(`*** Unhandled http Response in buildServiceMethod(${method.operationId}, ${methodKey}, ${pathKey}): ${JSON.stringify(method.responses)}\n     --> Could not link http method and response to any K2 Service Object`);
                        return undefined;
                    }
                }
                    
            }
            else {
                if (method.requestBody != undefined) { //object in body for post
                    let content = method.requestBody.content["application/json"] || method.requestBody.content["text/json"];
                    if(content && content.schema.$ref) {
                        newServiceMethod.methodObject = content.schema.$ref.replace("#/components/schemas/","");
                        newServiceMethod.methodDefinition.inputs = this.objPropertiesToArray(this.jsspPostSchema.objects[newServiceMethod.methodObject].properties);
                        switch (methodKey) {
                            case "post":
                                newServiceMethod.methodDefinition.type = "create";
                                break;
                            case "patch":
                                newServiceMethod.methodDefinition.type = "update";
                                break;
                            case "put":
                                newServiceMethod.methodDefinition.type = "update";
                                break;
                            case "delete":
                            newServiceMethod.methodDefinition.type = "delete";
                            break;
                            default:
                                break;
                        }
                    }
                    else {
                        this.errors.push(`Unhandled http Response in buildServiceMethod(${method.operationId}, ${methodKey}, ${pathKey}): ${JSON.stringify(method.responses)}\n     --> Could not link http method and response to any K2 Service Object`);
                        return undefined;
                    }
                    
                } else {
                    this.errors.push(`Unhandled http Response in buildServiceMethod(${method.operationId}, ${methodKey}, ${pathKey}): ${JSON.stringify(method.responses)}\n     --> Could not link http method and response to any K2 Service Object`);
                    return undefined;
                }
            }
                
            //Add Parameters / Inputs
            //get or delete --> Parameters
            //post or put --> Inputs
   
            if (method.parameters != undefined) {
                method.parameters.forEach((parameter) => {
                    this.globalCounter++;
                    let paramObject = parameter;
                    if(paramObject.$ref != undefined)  { //specified under swagger parameters section
                        let parameRefName = paramObject.$ref.replace("#/components/parameters/","");
                        paramObject = this.openapiFile.components.parameters[parameRefName];
                    }
                    let paramType: string = undefined;
                    if(paramObject.hasOwnProperty("schema")) {
                        paramType = paramObject.schema.type || (paramObject.schema.anyOf ? paramObject.schema.anyOf[0].type : undefined)
                    }

                    if (paramType != undefined) {
                        let k2Type:ServiceValueType = "string";
                        switch (paramType) {
                            case "integer":
                                k2Type = "number";
                                break;
                            case "number":
                                k2Type = "decimal";
                                break;
                            case "boolean":
                                    k2Type = "boolean";
                                    break;
                            default:
                                k2Type = "string"
                                break;
                        }
                        if(paramObject.name.toLowerCase() != "$count" && paramObject.name.toLowerCase() != "$expand" && paramObject.name.toLowerCase() != "$search" ) {
                            newServiceMethod.methodDefinition.parameters[paramObject.name] = {
                                displayName: paramObject.name,
                                type: k2Type,
                            };
                        }
                    }
                    if (paramObject.hasOwnProperty("required") && paramObject.required && paramType != undefined && paramObject.name.toLowerCase() != "$count" && paramObject.name.toLowerCase() != "$expand" && paramObject.name.toLowerCase() != "$search") {
                        newServiceMethod.methodDefinition.requiredParameters.push(
                            paramObject.name);
                    }

                });
            }

            //check if we need to add properties and inputs for list and $filter params:
            if(newServiceMethod.methodDefinition.type === "list" && newServiceMethod.methodDefinition.parameters.hasOwnProperty("$filter")) {
               newServiceMethod.methodDefinition.inputs = this.objPropertiesToArray(this.jsspPostSchema.objects[newServiceMethod.methodObject].properties, true);
            }
    
            if(newServiceMethod.methodName === undefined) {
                newServiceMethod.methodName = newServiceMethod.methodDefinition.type+newServiceMethod.methodObject;
            }
    
            newServiceMethod.methodDefinition.data = {
                httpMethod: methodKey,
                httpPath: pathKey,
                httpResponseObject: embeddedResponseObject
            }

            //handle 'functions' in URL and string params
            for (const paramKey in newServiceMethod.methodDefinition.parameters) {
                if(newServiceMethod.methodDefinition.parameters[paramKey].type === "string") {
                    newServiceMethod.methodDefinition.data.httpPath = newServiceMethod.methodDefinition.data.httpPath.replace(`({${paramKey}})`,`('{${paramKey}}')`);
                    newServiceMethod.methodDefinition.data.httpPath = newServiceMethod.methodDefinition.data.httpPath.replace(`(${paramKey}={${paramKey}})`,`(${paramKey}='{${paramKey}}')`);
                }
            }


        } catch (error) {
            this.errors.push(`Error with buildServiceMethod(${method.operationId}, ${methodKey}, ${pathKey}): ${error}`);
            newServiceMethod = undefined;
        }
        return newServiceMethod;
    }

    private getRefObject(httpResponse_schema: any, methodKey: string): RefObjectMethod {
        let returnObject:RefObjectMethod = { 
            $refObject:undefined, 
            k2method:undefined,  
            embeddedResponseObject: ""
             
        };

        if (httpResponse_schema.type === "array") {
            returnObject.$refObject = httpResponse_schema.items.$ref || (httpResponse_schema.items.anyOf && httpResponse_schema.items.anyOf[0].$ref);
            returnObject.k2method = "list";
        }

        if (httpResponse_schema.type === "object") {
            let firstObjectProperty = "value";
            for (const propkey in httpResponse_schema.properties) {
                firstObjectProperty = propkey;
                returnObject.embeddedResponseObject = propkey;
                break;    
            }
            if(httpResponse_schema.properties[firstObjectProperty] && httpResponse_schema.properties[firstObjectProperty].type === "array") {
                returnObject.$refObject = httpResponse_schema.properties.value.items.$ref || (httpResponse_schema.properties.value.items.anyOf && httpResponse_schema.properties.value.items.anyOf[0].$ref);
                returnObject.k2method = "list";
            }
        }

        if(httpResponse_schema.type != "array" && httpResponse_schema.type != "object") {
            returnObject.$refObject = httpResponse_schema.$ref || (httpResponse_schema.anyOf &&  httpResponse_schema.anyOf[0].$ref);
            switch (methodKey) {
                case "get":
                    returnObject.k2method = "read";
                    break;
                case "post":
                    returnObject.k2method = "create";
                    break;
                case "put":
                    returnObject.k2method = "update";
                    break;
                case "patch":
                    returnObject.k2method = "update";
                    break;
                case "delete":
                    returnObject.k2method = "delete";
                    break;
                default:
                    break;
            }
        }
        if(returnObject.$refObject)
            returnObject.$refObject = returnObject.$refObject.replace("#/components/schemas/", "");
        return returnObject;
    }

    private buildUnPackServiceMethod(
        methodType: ServiceMethodType,
        methodObject: string): NewServiceMethod {
        //methodObject here is actually the property which contains the name of the Object
        //e.g. address.Geo --> Geo is the object
        if (methodObject === "string") {
            return undefined;
        }

        try {
            let newServiceMethod: NewServiceMethod = {
                methodName: `UnpackJSON${
          methodType == "list" ? "ObjectArray" : "Object"
        }`,
                methodObject: methodObject,
                methodDefinition: {
                    displayName: `Unpack JSON ${
            methodType == "list" ? "Object Array" : "Object"
          }`,
                    type: methodType,
                    inputs: [],
                    requiredInputs: [],
                    parameters: {
                        "JSON.String.Param": {
                            displayName: `JSON ${methodObject} ${
                methodType == "list" ? "Object Array" : "Object"
              } String`,
                            description: "JSON String",
                            type: "string",
                            extendedType: "k2.com/2019/memo",
                        },
                    },
                    requiredParameters: ["JSON.String.Param"],
                    outputs: this.objPropertiesToArray(
                        this.jsspPostSchema.objects[methodObject].properties),
                },
            };
            return newServiceMethod;
        } catch (error) {
            console.log(
`Error in: buildUnPackServiceMethod(${methodType}, ${methodObject})`);
            return undefined;
        }
    }


    private buildPackServiceMethod(
        //methodType: ServiceMethodType,
        methodObject: string): NewServiceMethod {
        //methodObject here is actually the property which contains the name of the Object
        //e.g. address.Geo --> Geo is the object
        if (methodObject === "string") {
            return undefined;
        }

        try {
            let newServiceMethod: NewServiceMethod = {
                methodName: "PackJSONObject",
                methodObject: methodObject,
                methodDefinition: {
                    displayName: "Pack JSON Object",
                    type: "read",
                    inputs: this.objPropertiesToArray(this.jsspPostSchema.objects[methodObject].properties),
                    outputs: ["JSON.String"],
                },
            };
            return newServiceMethod;
        } catch (error) {
            console.log(`Error in: buildPackServiceMethod(${methodObject})`);
            return undefined;
        }
    }

    private objPropertiesToArray(objProperties: {
        [name: string]: ServiceProperty;
    }, ignoreMemo:boolean = false): string[]{
        let newArray: string[] = [];
        for (const propKey in objProperties) {
            if (objProperties.hasOwnProperty(propKey)) {
                if(!ignoreMemo || (ignoreMemo && (objProperties[propKey].type != "extendedString"))) {
                    newArray.push(propKey);
                } 
            }
        }
        return newArray;
    }
}

