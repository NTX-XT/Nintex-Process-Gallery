import * as fs from 'fs';

export function writeTextToFile(filedir: string, fileName: string, text: string) {
    if (!fs.existsSync(filedir)) {
        fs.mkdirSync(filedir);
    }

    if (fs.existsSync(`${filedir}/${fileName}`)) {
        let suffix = 1;
        while(fs.existsSync(`${filedir}/${fileName}_bak${suffix}`)) {
            suffix++;
        }
        fs.renameSync(`${filedir}/${fileName}`,`${filedir}/${fileName}_bak${suffix}`);
    }

    fs.writeFileSync(`${filedir}/${fileName}`,text);
}

export function readDataFromFile(fileName: string,):any {
    try {
        const data = fs.readFileSync(fileName, 'utf8')
        return JSON.parse(data);
    } catch (err) {
        //console.error(err);
        throw(err);
    }    
}

export function fileExists(fileName: string,):boolean {
    return fs.existsSync(fileName);
}

