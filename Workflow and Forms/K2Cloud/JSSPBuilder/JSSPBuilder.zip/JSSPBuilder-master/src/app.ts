#!/usr/bin/env node 
import chalk from "chalk";
import clear from "clear";
import figlet from "figlet";
import { PostSchemaBuilderFromSwagger2 } from "./lib/describeswagger2";
import * as fileservice from "./lib/fileservice";
import beautify from "js-beautify";
import minimist from "minimist";
import readline from "readline-sync";
import { TSCodeBuilder } from "./lib/buildcode";
import { PostSchemaBuilderFromOpenAPI3 } from "./lib/describeopenapi3";

let startTime = Date.now();

clear();
console.log(
  chalk.greenBright(
    figlet.textSync('JSSPBuilder', { horizontalLayout: 'full' })
  )
)

const args = minimist(process.argv.slice(2));

getInputs();

console.log(chalk.blueBright(`Starting to generate code...`));

let metaData: BrokerMetadata = {
  systemName: "com.k2.jssp.broker",
  displayName: "JSSP Broker",
  description: "A K2 JSSP Broker",
  configuration: {
    "ServiceURL": {
        displayName: "Service URL",
        type: "string",
        value: ""
    }
  }
};

let useAnonymousForAuth = false;
let errors: string[] = [];

let levels2Flatten = args['flatten'];
let swaggerFileName = args['filename'];

console.log(`Reading Swagger File...`);

let swaggerData = fileservice.readDataFromFile(swaggerFileName);

let definitionVersion = updateMetaDataFromSwagger();
console.log(`Building Describe Schema...`);

let postSchema:AbstractFolder = undefined;

if(definitionVersion === "2") {
  let mySchemaBuilderFromSwagger2 = new PostSchemaBuilderFromSwagger2(swaggerData, levels2Flatten);
  postSchema = mySchemaBuilderFromSwagger2.describeSchema();
  useAnonymousForAuth = !mySchemaBuilderFromSwagger2.requiresAuth;
  errors = mySchemaBuilderFromSwagger2.errors;
}

if(definitionVersion === "3") {
  let mySchemaBuilderFromOpenAPI3 = new PostSchemaBuilderFromOpenAPI3(swaggerData, levels2Flatten);
  postSchema = mySchemaBuilderFromOpenAPI3.describeSchema();
  useAnonymousForAuth = !mySchemaBuilderFromOpenAPI3.requiresAuth;
  errors = mySchemaBuilderFromOpenAPI3.errors;
}

if(postSchema === undefined) {
  throw new Error(`Unable to open and read a Swagger v2.0 or OpenAPI v3.0 definition from ${swaggerFileName}`)
}

let myCodeBuilder = new TSCodeBuilder(postSchema, metaData, levels2Flatten, useAnonymousForAuth);
console.log(`Generating Execute methods...`);
let myCode:string = myCodeBuilder.buildTypeScriptFile();
console.log(`Writing TypeScript File ./${args['outputdir']}/index.ts ...`);
fileservice.writeTextToFile(args['outputdir'],"index.ts",beautify(myCode,));

console.log();
if(errors.length > 0)
  console.log(chalk.bold.underline.yellow("Warnings:"));
errors.forEach(error => {
  console.log(chalk.yellow(`       ${error}`));
});
console.log();
console.log(chalk.whiteBright(`Broker Code File written to: ${chalk.greenBright.bold(args['outputdir']+"/index.ts")}`));
console.log();
console.log(`All Done in ${Date.now() - startTime} milliseconds !!!`);
console.log();

function updateMetaDataFromSwagger():string {
  let swaggerVersion:string  = swaggerData.swagger;

  if(swaggerData.info["title"] != undefined) {
    let brokerName:string = swaggerData.info["title"];
    metaData.systemName = `${brokerName.toLowerCase().replace(" ",".")}.jssp.broker`;
    metaData.displayName = `${brokerName} JSSP Broker`;
  }
  
  if(swaggerData.info["description"] != undefined) {
    metaData.description = swaggerData.info["description"];
  }

  if(swaggerVersion != undefined && swaggerVersion.startsWith("2")) { //we have a Swagger v2.0 definition
    swaggerVersion = "2";
    if(swaggerData.info["title"] != undefined) {
      let brokerName:string = swaggerData.info["title"];
      metaData.systemName = `${brokerName.toLowerCase().replace(" ",".")}.jssp.broker`;
      metaData.displayName = `${brokerName} JSSP Broker`
    }
    
    if(swaggerData.info["description"] != undefined) {
      metaData.description = swaggerData.info["description"];
    }
    
    try {
      metaData.configuration["ServiceURL"].value = `${swaggerData.schemes[0]}://${swaggerData.host}`;
    } catch (error) {
      console.error(error);
    }
  }
  else {
    swaggerVersion = swaggerData.openapi;
    if(swaggerVersion != undefined && swaggerVersion.startsWith("3")) { //we have an OpenApi v3.0 definition
      swaggerVersion = "3";
      try {
        metaData.configuration["ServiceURL"].value = `${swaggerData.servers[0].url}`;
      } catch (error) {
        console.error(error);
      }
    }
  }
  return swaggerVersion;
}

function getInputs(): void {
  if(args['help'] != undefined) {
    console.log(chalk.bold(chalk.greenBright("Usage:")));
    console.log(chalk.yellow("jsspbuilder --filename=[your_swagger].json --flatten=2 --outputdir=src"));
    console.log();
    process.exit();
  }

  if(args['filename'] === undefined) {
    args['filename'] = readline.question("Input Swagger v2.0/OpenAPI v3.0 definition file (Enter for swagger.json): ");
    if(args['filename'] === "") {
      args['filename'] = "swagger.json";
    }
  }
  
  if(!fileservice.fileExists(args['filename'])) {
    console.log(chalk.red(`Sorry, a file named ${args['filename']} could not be found.`));
    process.exit();
  }
  
  if(args['flatten'] === undefined) {
    args['flatten'] = readline.question("How many levels of Flattening do you want (Enter for 1): ");
    if(args['flatten'] === "") {
      args['flatten'] = 1;
    }
  }
  
  if(args['outputdir'] === undefined) {
    args['outputdir'] = readline.question("Output directory name (Enter for src): ");
    if(args['outputdir'] === "") {
      args['outputdir'] = "src";
    }
  }
}

