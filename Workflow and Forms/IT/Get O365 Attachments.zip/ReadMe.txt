This workflow gets attachment(s) from a SharePoint Online item and stores them in a SharePoint library. Run as a component workflow from a Nintex Office 365 instance. 

Start Variables:
Title - Text
ItemID - Integer

Workflow Key: NDuZHJ92juV6CYX8LivTffsS9zXQoFSHt7XUFSpzWj2hbVKPp