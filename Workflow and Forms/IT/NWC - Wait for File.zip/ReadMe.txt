This workflow will wait for the designated file to appear in a cloud file hosting service folder. Provide the two Start Variables and the workflow will then query the location until the specified file appears.

Start Variables:
stFileName - Text - expected as "Filename.txt"
stFilePath - Text - expected as "/Folder 1/Folder 2/etc"

NOTE: This workflow is built to query a OneDrive connection. The Start Variable "stFilePath" may need a different format for different cloud file hosting services.

Workflow Key: PBtDbyiyajowV6qeEyAmfffZMA1PRL9YVjdS57XQYydzu5SBk