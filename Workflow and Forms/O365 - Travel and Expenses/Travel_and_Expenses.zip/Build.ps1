$subScriptDir = Split-Path ((Get-Variable MyInvocation -Scope 0).Value).MyCommand.Path

$listExpenses = "Expense Reports"
$urlExpenses = "ExpenseReports"
$iconExpenses = "ExpenseReportMobileIcon.png"
New-PnPList -Title $listExpenses -Template GenericList -Url "$($SpListUrl.Lists)/$urlExpenses" | Out-Null
Set-PnPField -List $listExpenses -Identity "Title" -Values @{Title="Title"; Required=$true}
Add-PnPField -Type User -List $listExpenses -InternalName "Employee" -DisplayName "Employee" -Required -AddToDefaultView | Out-Null
Add-PnPField -Type DateTime -List $listExpenses -InternalName "SubmittedOn" -DisplayName "Submitted On" -AddToDefaultView | Out-Null
Set-SmsFieldSchema -List $listExpenses -Identity "SubmittedOn" -Values @{Format="DateOnly"}
Add-PnPField -Type Choice -List $listExpenses -InternalName "SaveAction" -DisplayName "Save Action" -Required -AddToDefaultView `
    -Choices @("Draft","Submit") | Out-Null
Set-SmsFieldSchema -List $listExpenses -Identity "SaveAction" -Values @{Format="RadioButtons"}
Add-PnPField -Type Currency -List $listExpenses -InternalName "GrandTotal" -DisplayName "Grand Total" -AddToDefaultView | Out-Null
Set-SmsFieldSchema -List $listExpenses -Identity "GrandTotal" -Values @{Decimals=2}
Add-PnPField -Type Note -List $listExpenses -InternalName "LineItems" -DisplayName "Line Items" | Out-Null
Add-PnPField -Type Text -List $listExpenses -InternalName "Status" -DisplayName "Status" -AddToDefaultView | Out-Null
Add-PnPField -Type DateTime -List $listExpenses -InternalName "ReviewedOn" -DisplayName "Reviewed On" -AddToDefaultView | Out-Null
Set-SmsFieldSchema -List $listExpenses -Identity "ReviewedOn" -Values @{Format="DateOnly"}
Add-PnPField -Type User -List $listExpenses -InternalName "ReviewedBy" -DisplayName "Reviewed By" -AddToDefaultView | Out-Null

$listTravelRequests = "Travel Requests"
$urlTravelRequests = "TravelRequests"
$iconTravelRequests = "TravelRequestMobileIcon.png"
New-PnPList -Title $listTravelRequests -Template GenericList -Url "$($SpListUrl.Lists)/$urlTravelRequests" | Out-Null
Set-PnPField -List $listTravelRequests -Identity "Title" -Values @{Title="Title"; Required=$true}
Add-PnPField -Type User -List $listTravelRequests -InternalName "Employee" -DisplayName "Employee" -Required -AddToDefaultView | Out-Null
Add-PnPField -Type Note -List $listTravelRequests -InternalName "ReasonForTravel" -DisplayName "Reason for Travel" | Out-Null
Add-PnPField -Type Note -List $listTravelRequests -InternalName "Flights" -DisplayName "Flights" | Out-Null
Add-PnPField -Type Note -List $listTravelRequests -InternalName "Hotels" -DisplayName "Hotels" | Out-Null
Add-PnPField -Type Currency -List $listTravelRequests -InternalName "TotalCostTrip" -DisplayName "Total Cost of Trip" -AddToDefaultView | Out-Null
Set-SmsFieldSchema -List $listTravelRequests -Identity "TotalCostTrip" -Values @{Decimals=2}
Add-PnPField -Type Currency -List $listTravelRequests -InternalName "TotalCostFlights" -DisplayName "Total Cost of Flights" -AddToDefaultView | Out-Null
Set-SmsFieldSchema -List $listTravelRequests -Identity "TotalCostFlights" -Values @{Decimals=2}
Add-PnPField -Type Currency -List $listTravelRequests -InternalName "TotalCostHotels" -DisplayName "Total Cost of Hotels" -AddToDefaultView | Out-Null
Set-SmsFieldSchema -List $listTravelRequests -Identity "TotalCostHotels" -Values @{Decimals=2}
Add-PnPField -Type Currency -List $listTravelRequests -InternalName "TotalCostOtherExpenses" -DisplayName "Total Cost of Other Expenses" -AddToDefaultView | Out-Null
Set-SmsFieldSchema -List $listTravelRequests -Identity "TotalCostOtherExpenses" -Values @{Decimals=2}
Add-PnPField -Type Note -List $listTravelRequests -InternalName "OtherExpenses" -DisplayName "OtherExpenses" | Out-Null
Add-PnPField -Type DateTime -List $listTravelRequests -InternalName "TripStartDate" -DisplayName "Trip Start Date" -Required -AddToDefaultView | Out-Null
Set-SmsFieldSchema -List $listTravelRequests -Identity "TripStartDate" -Values @{Format="DateOnly"}
Add-PnPField -Type DateTime -List $listTravelRequests -InternalName "TripEndDate" -DisplayName "Trip End Date" -Required -AddToDefaultView | Out-Null
Set-SmsFieldSchema -List $listTravelRequests -Identity "TripEndDate" -Values @{Format="DateOnly"}
Add-PnPField -Type Text -List $listTravelRequests -InternalName "Status" -DisplayName "Status" -AddToDefaultView | Out-Null
Add-PnPField -Type Boolean -List $listTravelRequests -InternalName "SubmittedForExpenses" -DisplayName "Submitted for Expenses" -AddToDefaultView | Out-Null
Get-SmsDefaultView -List $listTravelRequests | Set-SmsViewOrderBy -List $listTravelRequests -Fields @{ID=$false}

# Create content. Use actor-specific connection/web/list/item objects to control CreatedBy user info.
Add-SmsListItem -List $listExpenses -UserIndex 1 -Values @{
    Title="Field Research";
    Employee= $UserInfo[1].Uid;
    SubmittedOn=(Get-RelativeDate -Weeks -1 -DayOfWeek Monday -Utc);
    SaveAction="Submit"; GrandTotal=1300.00; Status="Approved";
    LineItems = (
        Format-NfRepeatingSection -HashTableArray @(
            @{ItemType="Flight"; ItemDate=(Get-Date -Month 4 -Day 13 -Year 2017); ItemDescription="SEA-DFW"; ItemAmount=200},
            @{ItemType="Flight"; ItemDate=(Get-Date -Month 4 -Day 15 -Year 2017); ItemDescription="DFW-ATL"; ItemAmount=200},
            @{ItemType="Hotel"; ItemDate=(Get-Date -Month 4 -Day 15 -Year 2017); ItemDescription="Hyatt Dallas"; ItemAmount=200},
            @{ItemType="Hotel"; ItemDate=(Get-Date -Month 4 -Day 16 -Year 2017); ItemDescription="Atlanta Hilton"; ItemAmount=200},
            @{ItemType="Hotel"; ItemDate=(Get-Date -Month 4 -Day 17 -Year 2017); ItemDescription="Hyatt Dallas"; ItemAmount=100},
            @{ItemType="Other"; ItemDate=(Get-Date -Month 4 -Day 13 -Year 2017); ItemDescription="Taxi"; ItemAmount=60},
            @{ItemType="Other"; ItemDate=(Get-Date -Month 4 -Day 13 -Year 2017); ItemDescription="Taxi"; ItemAmount=50},
            @{ItemType="Other"; ItemDate=(Get-Date -Month 4 -Day 15 -Year 2017); ItemDescription="Taxi"; ItemAmount=50},
            @{ItemType="Other"; ItemDate=(Get-Date -Month 4 -Day 15 -Year 2017); ItemDescription="Taxi"; ItemAmount=40},
            @{ItemType="Other"; ItemDate=(Get-Date -Month 4 -Day 16 -Year 2017); ItemDescription="Taxi"; ItemAmount=40},
            @{ItemType="Other"; ItemDate=(Get-Date -Month 4 -Day 16 -Year 2017); ItemDescription="Taxi"; ItemAmount=50},
            @{ItemType="Other"; ItemDate=(Get-Date -Month 4 -Day 17 -Year 2017); ItemDescription="Taxi"; ItemAmount=50},
            @{ItemType="Other"; ItemDate=(Get-Date -Month 4 -Day 17 -Year 2017); ItemDescription="Taxi"; ItemAmount=60}
        )
    )
}

Add-SmsListItem -List $listTravelRequests -UserIndex 1 -Values @{
    Title="Field Research";
    Employee= $UserInfo[1].Uid;
    ReasonForTravel= "Conduct customer interviews onsite in two cities.";
    Flights = (
        Format-NfRepeatingSection -HashTableArray @(
            @{
                FlightFrom="SEA"; DepartureDate=(Get-Date -Month 9 -Day 13 -Year 2017);
                FlightTo="DFW"; ReturnDate=(Get-Date -Month 9 -Day 17 -Year 2017); FlightCost=200
            },
            @{
                FlightFrom="DFW"; DepartureDate=(Get-Date -Month 9 -Day 15 -Year 2017);
                FlightTo="ATL"; ReturnDate=(Get-Date -Month 9 -Day 16 -Year 2017); FlightCost=200
            }
        )
    );
    Hotels = (
        Format-NfRepeatingSection -HashTableArray @(
            @{
                HotelName="Hyatt Dallas"; HotelAddress="1313 Generic Drive";
                CheckInDate=(Get-Date -Month 9 -Day 13 -Year 2017);
                CheckOutDate=(Get-Date -Month 9 -Day 15 -Year 2017); HotelCost=200
            },
            @{
                HotelName="Atlanta Hilton"; HotelAddress="5555 Example Lane";
                CheckInDate=(Get-Date -Month 9 -Day 15 -Year 2017);
                CheckOutDate=(Get-Date -Month 9 -Day 16 -Year 2017); HotelCost=200
            },
            @{
                HotelName="Hyatt Dallas"; HotelAddress="1313 Generic Drive";
                CheckInDate=(Get-Date -Month 9 -Day 16 -Year 2017);
                CheckOutDate=(Get-Date -Month 9 -Day 17 -Year 2017); HotelCost=100
            }
        )
    );
    OtherExpenses = (
        Format-NfRepeatingSection -HashTableArray @(
            @{OtherExpense="Taxi to SEA"; OtherExpenseDate=(Get-Date -Month 4 -Day 13 -Year 2017); OtherExpenseCost=60.00},
            @{OtherExpense="Taxi from DFW"; OtherExpenseDate=(Get-Date -Month 4 -Day 13 -Year 2017); OtherExpenseCost=50.00},
            @{OtherExpense="Taxi to DFW"; OtherExpenseDate=(Get-Date -Month 4 -Day 15 -Year 2017); OtherExpenseCost=50.00},
            @{OtherExpense="Taxi from ATL"; OtherExpenseDate=(Get-Date -Month 4 -Day 15 -Year 2017); OtherExpenseCost=40.00},
            @{OtherExpense="Taxi to ATL"; OtherExpenseDate=(Get-Date -Month 4 -Day 16 -Year 2017); OtherExpenseCost=40.00},
            @{OtherExpense="Taxi from DFW"; OtherExpenseDate=(Get-Date -Month 4 -Day 16 -Year 2017); OtherExpenseCost=50.00},
            @{OtherExpense="Taxi to DFW"; OtherExpenseDate=(Get-Date -Month 4 -Day 17 -Year 2017); OtherExpenseCost=50.00},
            @{OtherExpense="Taxi from SEA"; OtherExpenseDate=(Get-Date -Month 4 -Day 17 -Year 2017); OtherExpenseCost=60.00}
        )
    );
    TotalCostTrip=1300.00; TotalCostFlights=400.00; TotalCostHotels=500.00; TotalCostOtherExpenses=400.00;
    TripStartDate=(Get-RelativeDate -Weeks -2 -DayOfWeek Monday -Utc);
    TripEndDate=(Get-RelativeDate -Weeks -2 -DayOfWeek Saturday -Utc);
    Status="";
    SubmittedForExpenses="1"
}

Add-SmsListItem -List $listTravelRequests -UserIndex 2 -Values @{
    Title="Annual Conference";
    Employee= $UserInfo[1].Uid;
    ReasonForTravel= "Our annual industry conference.";
    Flights = (
        Format-NfRepeatingSection -HashTableArray @(
            @{
                FlightFrom="SEA";
                DepartureDate=(Get-Date -Month 9 -Day 13 -Year 2017);
                FlightTo="DFW"; ReturnDate=(Get-Date -Month 9 -Day 17 -Year 2017); FlightCost=200
            }
        )
    );
    Hotels = (
        Format-NfRepeatingSection -HashTableArray @(
            @{
                HotelName="Hyatt Dallas"; HotelAddress="1313 Generic Drive";
                CheckInDate=(Get-Date -Month 9 -Day 13 -Year 2017);
                CheckOutDate=(Get-Date -Month 9 -Day 15 -Year 2017); HotelCost=400
            }
        )
    );
    TotalCostTrip=820.00; TotalCostFlights=200.00; TotalCostHotels=400.00; TotalCostOtherExpenses=220.00;
    OtherExpenses = (
        Format-NfRepeatingSection -HashTableArray @(
            @{OtherExpense="Taxi to SEA"; OtherExpenseDate=(Get-Date -Month 9 -Day 13 -Year 2017); OtherExpenseCost=60.00},
            @{OtherExpense="Taxi from DFW"; OtherExpenseDate=(Get-Date -Month 9 -Day 13 -Year 2017); OtherExpenseCost=50.00},
            @{OtherExpense="Taxi to DFW"; OtherExpenseDate=(Get-Date -Month 9 -Day 17 -Year 2017); OtherExpenseCost=50.00},
            @{OtherExpense="Taxi from SEA"; OtherExpenseDate=(Get-Date -Month 9 -Day 17 -Year 2017); OtherExpenseCost=60.00}
        )
    );
    TripStartDate=(Get-RelativeDate -Weeks -2 -DayOfWeek Monday -Utc);
    TripEndDate=(Get-RelativeDate -Weeks -2 -DayOfWeek Saturday -Utc);
    Status="";
    SubmittedForExpenses="0"
}


#Add-NwLookupItem "TeQueryUserName" ($UserInfo[2].Email)
#Add-NwLookupItem "TeQueryPassword" $ActorPassword

$pageTitle = "Travel and Expenses"
New-SmsWikiPage -Title $pageTitle
Add-SmsListViewPart -Page $pageTitle -List $listExpenses -ViewName $SpViewName.AllItems -Zone "Left"
Add-SmsListViewPart -Page $pageTitle -List $listTravelRequests -ViewName $SpViewName.AllItems -Zone "Left"

Add-SmsSolutionLink -Title $pageTitle `
    -LinkLocation (Get-SmsSitePageUrl $pageTitle) `
    -Description "Travel request and expense submissions/approvals." `
    -ImageFile "TravelAndExpenses.png" -ImagePath "$subScriptDir\SiteAssets" `
    -QuickLaunch -ChildLists $listTravelRequests, $listExpenses

Import-SmsSiteAsset -FileName $iconTravelRequests -Path "$subScriptDir\SiteAssets"
Import-NfForm -List $listTravelRequests -ContentType $SpContentTypeName.Item -FileName $urlTravelRequests -Path $subScriptDir
Import-NwWorkflow -List $listTravelRequests -FileName "ApproveTravel" -Path $subScriptDir
Import-NwWorkflow -List $listTravelRequests -FileName "TravelToExpense" -Path $subScriptDir

Import-SmsSiteAsset -FileName $iconExpenses -Path "$subScriptDir\SiteAssets"
Import-NfForm -List $listExpenses -ContentType $SpContentTypeName.Item -FileName $urlExpenses -Path $subScriptDir
Import-NwWorkflow -List $listExpenses -FileName "ProcessExpense" -Path $subScriptDir
