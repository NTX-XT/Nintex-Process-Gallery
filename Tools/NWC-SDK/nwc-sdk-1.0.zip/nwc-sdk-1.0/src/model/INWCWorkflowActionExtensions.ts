import { INWCWorkflowDefinitionExtensionUsage } from "./INWCWorkflowDefinitionExtensionUsage";


export interface INWCWorkflowActionExtensions {
    [key: string]: INWCWorkflowDefinitionExtensionUsage;
}
