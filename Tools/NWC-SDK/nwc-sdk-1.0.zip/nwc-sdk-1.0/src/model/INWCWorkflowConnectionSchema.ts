
export interface INWCWorkflowConnectionSchema {
    title: string;
    type: string;
    format: string;
    minLength: number;
}
