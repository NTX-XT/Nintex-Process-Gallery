
export interface INWCWorkflowActionRenderOptions {
    type: string;
    branchMenuCommands: null;
}
