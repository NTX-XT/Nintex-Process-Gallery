
export interface INWCWorkflowPublisedUrls {
    designerUrl: string;
}
