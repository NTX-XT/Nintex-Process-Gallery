
export interface INWCXcomponent {
    redirectUri: string;
    documentationUrl?: string;
    url: string;
}
