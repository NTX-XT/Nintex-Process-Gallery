
export interface INWCWorkflowDefinitionState {
    modified: boolean;
}
