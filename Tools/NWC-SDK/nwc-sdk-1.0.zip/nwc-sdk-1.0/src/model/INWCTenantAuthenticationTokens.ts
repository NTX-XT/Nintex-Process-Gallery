
export interface INWCClientApp {
    clientId: string;
    clientSecret: string;
}
