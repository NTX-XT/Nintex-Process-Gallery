
export interface INWCPermission {
    id: string;
    name: string;
    type: string;
}
