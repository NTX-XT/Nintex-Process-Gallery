

export interface INWCWorkflowEventType {
    id: string;
    name: string;
}
