export interface INWCConnectorActionInfo {
    type: string;
    name: string;
    enabled: boolean;
    configuration: any;
}
