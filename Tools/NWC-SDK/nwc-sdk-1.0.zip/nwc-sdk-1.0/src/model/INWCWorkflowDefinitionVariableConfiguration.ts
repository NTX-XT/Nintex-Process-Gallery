
export interface INWCWorkflowDefinitionVariableConfiguration {
    description?: string;
    defaultValue: string;
}
