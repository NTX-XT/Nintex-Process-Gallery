export interface INWCWorkflowActionXtensionConfiguration {
    operationId:   string;
    id:            string;
    isAsyncAction: boolean;
    engineVersion: number;
}
