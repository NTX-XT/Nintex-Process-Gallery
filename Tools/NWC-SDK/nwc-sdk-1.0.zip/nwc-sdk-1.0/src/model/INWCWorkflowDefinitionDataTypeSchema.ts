
export interface INWCWorkflowDefinitionDataTypeSchema {
    title: string;
    type: string;
    properties: any;
}
