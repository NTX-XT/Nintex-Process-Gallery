

export interface INWCTenantOAuthInfo {
    domain: string;
    clientId: string;
}
