
export interface INWCWorkflowDefinitionExtensionInfo {
    title: string;
    description: string;
    version: string;
}
