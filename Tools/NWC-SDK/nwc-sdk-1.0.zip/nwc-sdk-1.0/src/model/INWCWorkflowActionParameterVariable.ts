import { INWCWorkflowActionParameterValueType } from "./INWCWorkflowActionParameterValueType";


export interface INWCWorkflowActionParameterVariable {
    valueType: INWCWorkflowActionParameterValueType;
}
