export interface INWCWorkflowActionConstraintData {
    field: string;
    filterType?: string[];
    choices?: any[];
}
