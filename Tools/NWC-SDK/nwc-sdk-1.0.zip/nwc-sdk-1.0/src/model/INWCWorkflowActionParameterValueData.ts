export interface INWCWorkflowActionParameterValueData {
    value: any;
}
