
export interface INWCImportedWorkflowId {
    workflowId: string;
    workflowDesignVersion: string;
}
