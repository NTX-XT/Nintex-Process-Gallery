export interface INWCWorkflowActionConfigurationServerInfo {
    className: string;
}
