export interface INWCConnectorEventInfo {
    type: string;
    name: string;
    enabled: boolean;
}
